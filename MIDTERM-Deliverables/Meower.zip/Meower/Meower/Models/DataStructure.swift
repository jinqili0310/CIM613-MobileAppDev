//
//  DataStructure.swift
//  Meower
//
//  Created by Jinqi Li on 3/11/20.
//  Copyright © 2020 Jinqi Li. All rights reserved.
//

import UIKit

struct LikeData {

}
